@echo off
setlocal
cd /d "%~dp0backend"

echo.
echo ==========================================
echo   AI Judgment System 1.0.0-rc1
echo ==========================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python was not found.
    echo Install Python 3.12 and try again.
    echo.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Creating a local Python environment...
    python -m venv .venv
    if errorlevel 1 goto :error
)

echo [2/3] Installing/updating required packages...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :error

echo.
echo [3/3] Starting the local server...
echo.
echo Open this address in your browser:
echo.
echo     http://127.0.0.1:8000/
echo.
echo Press Ctrl+C in this window to stop the server.
echo.
".venv\Scripts\python.exe" -m uvicorn app.main:app --reload
goto :eof

:error
echo.
echo [ERROR] Setup or startup failed.
echo Copy the error message and send it to the developer.
echo.
pause
exit /b 1
