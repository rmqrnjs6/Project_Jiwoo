# Step 11 — System Health Improvements

이번 단계의 목표는 기능을 많이 늘리는 것이 아니라, 이미 있는 판단 시스템을 더 건강하게 만드는 것입니다.

## 1. 예전 판단 당시의 조건을 보존

### 문제
몇 달 뒤 모델이나 규칙, 근거가 바뀌면 "그때 왜 그렇게 판단했는지" 확인하기 어려울 수 있습니다.

### 수정
각 Judgment에 당시 AI가 본 입력, 근거 상태, 신뢰도, 모델, 규칙, 시스템 지시문을 내부 `decision_snapshot`으로 저장합니다. 일반 Judgment API 응답에는 이 전체 Snapshot을 그대로 노출하지 않아 응답 크기와 내부 정보 노출을 줄입니다.

### 결과
현재 데이터가 나중에 달라져도 당시 판단 조건을 따로 확인할 수 있습니다.

---

## 2. 왜 다시 판단했는지 기록

### 문제
"재판단"만 기록하면 새 근거 때문인지, 규칙 변경 때문인지, 사용자가 다시 요청했기 때문인지 알기 어렵습니다.

### 수정
다음과 같은 재판단 이유를 저장합니다.

- `INITIAL`
- `USER_REQUEST`
- `INPUT_CHANGED`
- `NEW_EVIDENCE`
- `SOURCE_VERIFIED`
- `SOURCE_DISPROVED`
- `RULE_CHANGED`
- `MODEL_CHANGED`
- `GRACE_PERIOD_EXPIRED`

### 결과
판단 변화의 원인을 History에서 추적할 수 있습니다.

---

## 3. 돈이 들 필요가 없는 AI 호출은 하지 않음

### 문제
입력, 근거, 규칙, 모델이 모두 그대로인데 `/judge`를 반복 호출하면 같은 판단을 위해 비용이 다시 발생할 수 있습니다.

### 수정
판단에 영향을 주는 조건 전체를 하나의 `decision_fingerprint`로 만듭니다.

이전 AI Judgment와 fingerprint가 같으면:

- OpenAI 호출을 하지 않습니다.
- 기존 Judgment를 그대로 반환합니다.
- History에 `AI_CALL_SKIPPED`를 남깁니다.

정말 같은 조건에서도 새 판단을 요청하고 싶으면:

```text
POST /cases/{case_id}/judge?force=true
```

를 사용할 수 있습니다.

### 결과
기본 동작은 비용을 아끼고, 사용자가 명확히 원하면 다시 판단할 수 있습니다.

---

## 4. 사람에게 보여줄 Timeline 분리

### 문제
Raw History는 정확하지만 이벤트가 많아질수록 사람이 읽기 어렵습니다.

### 수정
Raw History는 그대로 보존하고, 별도의 사용자용 Timeline을 제공합니다.

```text
GET /cases/{case_id}/timeline
```

`REEVALUATION_STARTED`, `REEVALUATION_COMPLETED` 같은 내부 이벤트는 Timeline에서 숨기고, 중요한 변화만 사람이 이해하기 쉬운 문장으로 보여줍니다.

Raw History는 감사/분석용, Timeline은 사용자 이해용입니다.

---

## 기존 SQLite DB를 계속 사용할 경우

Step 11은 `judgments` 테이블에 새 컬럼 3개를 추가합니다.

Step 10 DB를 유지하려면 먼저 백업 후 `backend/`에서 실행합니다.

```powershell
python scripts/migrate_step10_to_step11_sqlite.py
```

PostgreSQL은 이 간이 스크립트가 아니라 Alembic 같은 정식 migration 도입을 권장합니다.
