# Step 13 — Browser UI

## Goal

The backend was already testable through Swagger, but a normal user should not need to remember numeric IDs or raw API routes.

Step 13 adds a small browser UI that keeps the core workflow in one place.

## User flow

```text
Create Case
  ↓
Add Evidence
  ↓
Assess reliability / review source structure
  ↓
Request Judgment
  ↓
See current position and confidence
  ↓
Add new Evidence
  ↓
Request reevaluation
  ↓
Review Timeline
```

## Cost behavior

The standard AI Judgment button does not force a new paid request. The backend compares the current decision context with the previous AI Judgment and reuses the previous result when nothing relevant changed.

A separate `강제로 다시 판단` action maps to `POST /cases/{case_id}/judge?force=true` and is intentionally explicit.

## AI key behavior

When `OPENAI_API_KEY` is not configured, the UI shows that state and disables live Judgment buttons. Evidence, reliability, source checks, Case management, and Timeline remain usable without an AI call.

## Technical approach

The frontend is intentionally build-free for this internal stage:

- `frontend/index.html`
- `frontend/styles.css`
- `frontend/app.js`
- FastAPI serves the frontend at `/` and `/app`
- static assets are mounted under `/static`

This keeps local setup to one Python server while the product flow is still being validated. A framework-based frontend can replace this layer later without changing the core API.

## New API

```text
GET /cases
```

Returns lightweight Case summaries for navigation without exposing each Case's full original input in the list response.

## Verification

Step 13 checks include:

- browser page is served
- CSS/JS assets are served
- Case list API supports navigation
- `/app` alias works
- all previous backend regression tests remain green

Current result: **60 passed**.
