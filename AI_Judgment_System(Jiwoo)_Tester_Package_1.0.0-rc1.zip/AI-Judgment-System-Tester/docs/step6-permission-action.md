# Step 6 — Permission + Action Engine

## Goal
Separate AI judgment from execution. A judgment may recommend or trigger an action, but execution is permitted only when every gate passes.

## Execution gates
An action can execute only when all of the following are true:

1. `PERMISSION_ACTION` is unlocked by the release profile.
2. The referenced judgment belongs to the case.
3. The referenced judgment is the latest revision.
4. The judgment is `RESOLVED`.
5. The case permission has `can_execute=true`.
6. The requested action is included in `allowed_actions`.
7. The action parameters are valid.

Any failed gate produces a persisted blocked ActionAttempt and an `ACTION_BLOCKED` history event.

## Permission policy
Each case has a permission policy:

- `can_execute`: global execution switch for the case.
- `allowed_actions`: explicit execution scope.

Changing permission creates `PERMISSION_CHANGED` history with before/after snapshots.

## Internal actions in Step 6

- `SET_CASE_STATUS` (`OPEN` / `CLOSED`)
- `SET_CASE_TITLE`

These are intentionally limited to internal application state. External side effects are not connected yet.

## Audit trail

- `ACTION_ATTEMPTED`
- `ACTION_BLOCKED`
- `ACTION_COMPLETED`
- `ACTION_FAILED`

Blocked actions remain queryable through `/cases/{case_id}/actions` when the feature is unlocked.

## Release profile
`PERMISSION_ACTION` is locked in `V1` and enabled from `V1_5` onward.
