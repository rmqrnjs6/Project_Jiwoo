# Step 8 — Trust Hardening

이번 단계는 새 기능 확장이 아니라 기존 철학을 코드 경로 전체에서 더 일관되게 강제하는 보강 단계다.

## 1. Judgment consistency
- `SUPPORTED -> AGREE`
- `CONTRADICTED -> DISAGREE`
- `UNCERTAIN / INSUFFICIENT_EVIDENCE -> UNSURE`
- `RESOLVED`는 `SUPPORTED / CONTRADICTED`만 허용
- `PENDING / UNRESOLVED`는 불확실 결론만 허용
- API validator와 DB CheckConstraint 양쪽에서 검증
- Judgment에 `origin`(`MANUAL`, `AI_ENGINE`)과 `actor` 기록

## 2. Evidence provenance
Evidence 입력의 출처 메타데이터는 검증 전까지 claim으로 취급한다.

- `claimed_source_type`
- `claimed_is_primary_source`
- `source_verification_status = UNVERIFIED | VERIFIED | DISPUTED`
- `verified_source_type`
- `verified_is_primary_source`

`metadata-v2`는 미검증 출처 주장의 authority/originality/directness가 과도하게 높아지지 않도록 상한을 둔다.
사용자가 직접 넣은 reliability score도 보존하지만, 독립 평가 전 Judgment Engine에서는 최대 0.60으로 제한한다.

## 3. History preservation
- 기존 HistoryEvent UPDATE 거부
- 기존 HistoryEvent DELETE 거부
- History가 존재하는 Case의 물리 삭제를 FK `RESTRICT`로 차단
- SQLite에서도 foreign key enforcement 활성화

목표는 '영원한 불변'이 아니라, 과거를 지우는 대신 새로운 기록으로 정정할 수 있도록 변화 과정을 보존하는 것이다.

## Test result
`32 passed`
