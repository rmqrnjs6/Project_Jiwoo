# Step 5 — Release Lock + Response Composer

## Goal

Keep later-version code in the internal build while exposing only the features permitted by the active release profile.

## Release profiles

- V1: core judgment, re-evaluation
- V1.5: V1 + permission/action flag
- V2: V1.5 + contextual nudge + response composer
- V2.5: V2 + explain mode flag
- V3 / INTERNAL: all declared feature flags

The default public profile is `V1` via `RELEASE_PROFILE=V1`.

## Lock behavior

A locked feature returns HTTP 403 with `FEATURE_LOCKED`. For case-scoped requests, the blocked attempt is appended to History as `FEATURE_ACCESS_BLOCKED`.

## Response Composer

The composer uses the latest Judgment and latest SupportAssessment.

- NONE: judgment only
- SOFT: recommendation is woven into ordinary prose
- EXPLICIT: recommendation is a separate paragraph
- SAFETY: direct safety content is placed first and is never hidden
- revised judgment: a re-evaluation notice is included

Every successful composition appends `RESPONSE_COMPOSED` to History.
