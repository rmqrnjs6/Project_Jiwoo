# Step 10 — OpenAI Runtime Hardening

Step 10 hardens the real automatic judgment path without changing the core judgment semantics.

## Runtime contract

The production provider uses the OpenAI Responses API structured-output path:

- `client.responses.parse(...)`
- `text_format=EngineDecision`
- `store=False`
- default model: `gpt-5.6-luna`
- default timeout: 30 seconds
- default SDK retries: 1

The timeout/retry values can be overridden with:

```text
OPENAI_TIMEOUT_SECONDS=30
OPENAI_MAX_RETRIES=1
```

## Failure semantics

Provider failures are sanitized before they reach the API or History.

| Provider condition | API status | Error code | Retryable |
|---|---:|---|---|
| API key not configured | 503 | `OPENAI_NOT_CONFIGURED` | no |
| timeout | 504 | `OPENAI_TIMEOUT` | yes |
| connection failure | 503 | `OPENAI_CONNECTION_ERROR` | yes |
| rate limited | 429 | `OPENAI_RATE_LIMITED` | yes |
| authentication failure | 503 | `OPENAI_AUTHENTICATION_ERROR` | no |
| provider permission failure | 503 | `OPENAI_PERMISSION_DENIED` | no |
| rejected provider request | 502 | `OPENAI_REQUEST_REJECTED` | no |
| provider server error | 503 | `OPENAI_SERVER_ERROR` | yes |
| malformed / incomplete structured judgment | 502 | `OPENAI_INVALID_RESPONSE` | yes |

Raw provider exception text is not returned to the API consumer.

## Evidence binding

A model judgment must assess every Evidence item supplied to the request exactly once.
It cannot omit an Evidence ID, invent a new ID, or duplicate an assessment. Violations are rejected as `OPENAI_INVALID_RESPONSE` and no Judgment is committed.

## Failure history

Failed automatic judgments create a `JUDGMENT_FAILED` History event containing only safe operational metadata:

- provider
- model
- sanitized error code
- retryable flag
- provider request ID when available

No raw provider exception is persisted.

## Configuration visibility

`GET /ai/status` reports local configuration only. It does not make a paid/live provider request.

Example:

```json
{
  "provider": "openai",
  "configured": true,
  "model": "gpt-5.6-luna",
  "live_check_performed": false
}
```

## Manual live test

In Windows PowerShell, set the key for the current shell only:

```powershell
$env:OPENAI_API_KEY="YOUR_KEY"
$env:OPENAI_MODEL="gpt-5.6-luna"
$env:OPENAI_TIMEOUT_SECONDS="30"
$env:OPENAI_MAX_RETRIES="1"
```

Restart the FastAPI server after setting environment variables, then:

1. `GET /ai/status`
2. create a Case
3. add at least one Evidence item
4. `POST /cases/{case_id}/judge`
5. inspect `GET /cases/{case_id}/history`

A live API call was not executed as part of the automated test suite; automated tests use injected fake clients/providers so tests are deterministic and do not incur API cost.
