# Step 14 Release Checklist

## Verified here

- [x] 67 automated tests pass.
- [x] Application starts with the available local Python environment.
- [x] Browser UI is served successfully.
- [x] Database readiness probe succeeds on SQLite.
- [x] Status endpoints do not make a paid OpenAI call.
- [x] Paid live smoke test is disabled by default.
- [x] Cost Guard remains active for unchanged judgments.
- [x] Paid requests have output-token, reasoning-effort, input-size, and evidence-count limits.
- [x] Python source compiles.
- [x] `.env`, local DBs, virtual environments, and caches are excluded by `.gitignore` / `.dockerignore`.

## Requires local/external verification

- [ ] Run exactly one paid OpenAI smoke test with a user-owned API key.
- [ ] Run `docker compose up --build` on a machine with Docker.
- [ ] Confirm PostgreSQL container path end-to-end.
- [ ] Deploy to the chosen hosting platform and verify its environment variables, persistent DB, HTTPS, and logs.

## Post-RC backlog

- Authentication / user ownership
- High-write concurrency hardening
- Grace Period automation
- Semantic evidence cross-check
- Stronger external source authenticity verification
- Production DB migration framework
- Monitoring / alerting
