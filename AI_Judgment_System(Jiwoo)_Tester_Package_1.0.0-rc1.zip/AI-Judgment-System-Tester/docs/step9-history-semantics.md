# Step 9 — History Semantics Hardening

This step separates an attempted reevaluation from an actual state change.

## History semantics

- `JUDGMENT_REVISED`: the material judgment state changed.
- `JUDGMENT_REAFFIRMED`: the case was reevaluated, but the material judgment state stayed the same.
- `RELIABILITY_REVISED`: reliability components, final score, or assessment method changed.
- `RELIABILITY_REAFFIRMED`: reliability was reassessed with the same material result.
- `REEVALUATION_COMPLETED.payload.state_changed`: explicitly records whether the judgment state changed.
- `DUPLICATE_EVIDENCE_DETECTED`: an exact/normalized duplicate submission was detected and not added as a second evidence item.

## Additional hardening

- API response datetimes are normalized to explicit UTC.
- Case/evidence text is stripped and whitespace-only input is rejected.
- Swagger case examples use meaningful sample text instead of generic placeholders.
- Response Composer distinguishes “judgment updated” from “judgment maintained after review.”

## Duplicate evidence policy

Within one Case, Evidence is treated as a duplicate when normalized content and source URL match an existing Evidence item. The attempted submission is preserved in History, but no new Evidence row is created. The API returns HTTP 409 with the existing Evidence ID.
