# Step 4 — Contextual Nudge Layer

This layer observes language in the case input without diagnosing the author.

## Core distinction

- `affect_signals`: observable emotional language in the text.
- `context_mode`: only explicit context. If not declared, use `AMBIGUOUS_CONTEXT`.
- `nudge_level`: whether a recommendation is warranted.
- `delivery_style`: how directly the recommendation should be expressed.

The system never infers psychopathy, sociopathy, depression, personality disorders,
profession, deception, acting, authenticity, or talent from writing style.

## Nudge contract

| Nudge | Delivery |
| --- | --- |
| NONE | NONE |
| SOFT | SUBTLE |
| EXPLICIT | CLEAR |
| SAFETY | DIRECT_SAFETY |

A SAFETY response can never be hidden as a subtle nudge.

## API

`POST /cases/{case_id}/support-assess`

The assessment is persisted and creates `CONTEXT_ASSESSED`; when a recommendation
exists it also creates `NUDGE_GENERATED` in History.
