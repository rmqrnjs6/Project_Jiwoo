# Step 3 — Judgment Engine

## Goal

Automatically convert a Case + Evidence set into a versioned Judgment while preserving evidence-level traceability and history.

## Endpoint

`POST /cases/{case_id}/judge`

## Decision model

- `conclusion`: SUPPORTED / CONTRADICTED / UNCERTAIN / INSUFFICIENT_EVIDENCE
- `ai_position`: derived by the system from conclusion
  - SUPPORTED -> AGREE
  - CONTRADICTED -> DISAGREE
  - otherwise -> UNSURE
- `resolution_state`: RESOLVED / UNRESOLVED / PENDING
- `confidence`: 0.0–1.0
- `position_text`: user-facing current stance
- `reasoning_summary`: concise evidence-grounded explanation
- `waiting_for`: required for PENDING
- `unresolved_reason`: required for UNRESOLVED
- `evidence_assessments`: per-evidence stance, relevance, reliability, rationale

## Consistency rules

- RESOLVED only permits SUPPORTED or CONTRADICTED.
- PENDING only permits UNCERTAIN or INSUFFICIENT_EVIDENCE and requires `waiting_for`.
- UNRESOLVED only permits UNCERTAIN or INSUFFICIENT_EVIDENCE and requires `unresolved_reason`.
- AI position is not trusted from the model; it is derived by application code to prevent contradictory state combinations.

## AI provider

Production path uses OpenAI Responses structured output through `responses.parse(...)` with a Pydantic schema. The provider is isolated behind `JudgmentProvider` so tests can inject deterministic fakes and avoid external/paid calls.

The prompt explicitly tells the model:

- treat user input as the claim, not evidence;
- use only supplied Evidence as factual support;
- do not silently use pretrained memory as evidence;
- distinguish unresolved from pending;
- never manufacture a future event just to choose PENDING.

## Verification status

Local automated tests: 6 passed.

The live OpenAI network call is **not** verified in this environment because `OPENAI_API_KEY` is not configured. A no-key test verifies that the API fails transparently with HTTP 503 instead of pretending a judgment was produced.
