# Step 14 — Release Candidate / Deployment Readiness

Step 14 marks the first completion line for the current product scope.

## What changed

- Application version moved to `1.0.0-rc1`.
- Added `/ready` for database readiness checks without spending AI credits.
- Added `/system/status` for safe operational status without exposing secrets.
- Added an explicit one-call live OpenAI smoke-test script that is disabled by default.
- Added output-token and reasoning-effort limits for paid OpenAI judgment requests.
- Added Docker and Docker Compose deployment files.
- Added GitHub Actions regression testing.

## Cost protection

Ordinary automated tests and health/readiness endpoints make no OpenAI network request.
The paid live smoke test runs only when BOTH are set:

```text
OPENAI_API_KEY=...
RUN_PAID_OPENAI_SMOKE_TEST=YES
```

The script issues exactly one judgment request.

## Live test

From `backend/`:

```powershell
$env:OPENAI_API_KEY="..."
$env:RUN_PAID_OPENAI_SMOKE_TEST="YES"
python scripts/live_openai_smoke_test.py
```

Do not put the API key in source control.

## Deployment

Local single-server development:

```bash
cd backend
python -m uvicorn app.main:app --reload
```

Container deployment:

```bash
docker compose up --build
```

Open `http://127.0.0.1:8000/`.

## Deliberately deferred after RC

- User authentication / ownership policy
- Concurrency hardening for high-write multi-user workloads
- Grace Period automation
- Semantic evidence cross-check
- Strong external source authenticity verification
- Production migration framework such as Alembic
- Long-running production monitoring / alerting
