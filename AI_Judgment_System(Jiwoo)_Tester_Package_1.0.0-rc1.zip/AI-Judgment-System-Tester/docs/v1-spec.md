# AI Judgment V1 Specification

## Core Domain

V1 has six core concepts:

1. **Input** — the original claim/data to be evaluated.
2. **Evidence** — traceable material that can support or contradict the input.
3. **Judgment** — a point-in-time conclusion based on available evidence.
4. **Permission** — policy that determines what actions the system may execute.
5. **Action** — an actual attempted or completed operation.
6. **History** — append-only event history of meaningful system changes.

## History Principle

History is not a final step. It is a cross-cutting audit layer.

Every meaningful event should be recorded, including:

- INPUT_CREATED
- INPUT_UPDATED
- EVIDENCE_ADDED
- EVIDENCE_REJECTED
- JUDGMENT_CREATED
- JUDGMENT_REVISED
- PERMISSION_CHANGED
- ACTION_ATTEMPTED
- ACTION_BLOCKED
- ACTION_COMPLETED
- REEVALUATION_STARTED
- REEVALUATION_COMPLETED

Each history event should answer:

- What happened?
- When did it happen?
- Which case did it affect?
- What entity caused it?
- What changed?
- What was the result?

## V1 Judgment States

- SUPPORTED
- CONTRADICTED
- UNCERTAIN
- INSUFFICIENT_EVIDENCE

## V1 Permission Levels

- READ
- RECOMMEND
- EXECUTE

EXECUTE must still be constrained by an explicit execution scope.

## First Milestone

A working backend must support:

1. Create a Case containing original input.
2. Add Evidence to the Case.
3. Read a Case and its Evidence.
4. Read the Case History timeline.
5. Record every meaningful mutation as an append-only History event.

AI judgment generation is intentionally excluded from this milestone.
