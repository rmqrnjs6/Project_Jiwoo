# Step 12 — Source Verification Workflow

## Why this step exists

A user can say, “this is an official primary source,” but the system should not treat that statement as independently proven.

Step 12 separates three things:

1. What the user claimed about the source.
2. What the system has actually checked.
3. What has been strongly enough verified to affect source authority without the unverified cap.

## Default verification behavior

`POST /cases/{case_id}/evidence/{evidence_id}/verify-source`

The default verifier is deliberately local and makes **no network request**. It checks only whether the stored source URL is structurally plausible and points to a public-looking host.

Possible results include:

- `UNVERIFIED`: there was not enough source metadata to check.
- `PARTIALLY_VERIFIED`: the URL passed local structure/safety checks, but authenticity and authority are still unknown.
- `INVALID`: the URL failed local safety/structure checks.
- `VERIFIED`: reserved for a stronger verification provider that independently confirms the source.
- `DISPUTED`: a stronger verification process found a material conflict with the source claim.

The local verifier can never promote a source to `VERIFIED`.

## Reliability behavior

After source verification, the evidence reliability score is recalculated locally. This does not automatically trigger a paid AI judgment.

A true `VERIFIED` result can remove the metadata-v2 unverified cap. `PARTIALLY_VERIFIED` does not.

## Reevaluation reasons

Source changes are tracked separately from new evidence:

- `SOURCE_REVIEWED`: the source was checked but not fully verified.
- `SOURCE_VERIFIED`: stronger verification confirmed the source.
- `SOURCE_DISPROVED`: the source was disputed or invalidated.

This prevents a source review from being mislabeled as `NEW_EVIDENCE`.

## History

Each source verification attempt is versioned and preserved:

- `SOURCE_VERIFICATION_ASSESSED`
- `SOURCE_VERIFICATION_REVISED`
- `SOURCE_VERIFICATION_REAFFIRMED`

Repeated checks that reach the same result are reaffirmations rather than false revisions.

## Current limitation

The default provider does **not** visit the web, verify domain ownership, authenticate documents, or compare source contents. A future independent verification provider can plug into the same interface. Tests use an injected trusted provider to verify that a real `VERIFIED` result correctly affects reliability and reevaluation behavior.
