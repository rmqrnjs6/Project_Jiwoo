# AI Judgment System Backend — 1.0.0-rc1

## Run locally

Recommended: Python 3.12.

### Windows PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m uvicorn app.main:app --reload
```

If PowerShell activation is unavailable:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

Open:

- UI: `http://127.0.0.1:8000/`
- API docs: `http://127.0.0.1:8000/docs`
- Health: `http://127.0.0.1:8000/health`
- Readiness: `http://127.0.0.1:8000/ready`
- System status: `http://127.0.0.1:8000/system/status`
- AI status: `http://127.0.0.1:8000/ai/status`

## OpenAI

AI judgment requires `OPENAI_API_KEY`; the rest of the core application does not.

```powershell
$env:OPENAI_API_KEY="YOUR_KEY"
$env:OPENAI_MODEL="gpt-5.6-luna"
$env:OPENAI_TIMEOUT_SECONDS="30"
$env:OPENAI_MAX_RETRIES="1"
$env:OPENAI_MAX_OUTPUT_TOKENS="1800"
$env:OPENAI_REASONING_EFFORT="low"
$env:OPENAI_MAX_INPUT_CHARS="50000"
$env:OPENAI_MAX_EVIDENCE_ITEMS="25"
```

The Cost Guard reuses an unchanged AI judgment rather than spending another call. Oversized AI inputs are rejected locally before a paid request is sent.

### Explicit paid live smoke test

Disabled by default. It issues exactly one AI judgment request only after explicit opt-in:

```powershell
$env:RUN_PAID_OPENAI_SMOKE_TEST="YES"
python scripts/live_openai_smoke_test.py
```

Do not commit API keys.

## Test

```powershell
python -m pytest -q
```

Current Step 14 regression result: **67 passed**.

## Database

SQLite is the local default. PostgreSQL is supported through `DATABASE_URL` and the included `compose.yaml` provides a local container setup.

For older SQLite development databases, run the Step 11 and Step 12 migration scripts as appropriate. Step 13 and Step 14 add no database columns.
