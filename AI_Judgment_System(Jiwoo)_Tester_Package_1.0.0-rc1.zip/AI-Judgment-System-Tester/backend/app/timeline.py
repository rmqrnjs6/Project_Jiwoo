from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from .models import HistoryEvent, HistoryEventType


@dataclass
class TimelineItem:
    event_id: int
    event_type: HistoryEventType
    category: str
    title: str
    summary: str
    entity_type: str
    entity_id: int | None
    occurred_at: datetime
    event_count: int = 1


def _score(value) -> str:
    return "unknown" if value is None else f"{float(value):.2f}"


def _to_item(event: HistoryEvent) -> TimelineItem | None:
    p = event.payload or {}
    et = event.event_type

    # These are useful in the raw audit log, but too noisy for a human timeline.
    if et in {HistoryEventType.REEVALUATION_STARTED, HistoryEventType.REEVALUATION_COMPLETED}:
        return None

    if et == HistoryEventType.INPUT_CREATED:
        return TimelineItem(event.id, et, "case", "Case created", "The original input was recorded.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.EVIDENCE_ADDED:
        source = p.get("claimed_source_type", "UNKNOWN")
        status = p.get("source_verification_status", "UNVERIFIED")
        return TimelineItem(event.id, et, "evidence", "Evidence added", f"Source claim: {source}; verification: {status}.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.DUPLICATE_EVIDENCE_DETECTED:
        return TimelineItem(event.id, et, "evidence", "Duplicate evidence skipped", "The same evidence was already present, so it was not counted again.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.RELIABILITY_ASSESSED:
        return TimelineItem(event.id, et, "reliability", "Reliability assessed", f"Evidence reliability was assessed at {_score(p.get('final_score'))}.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.RELIABILITY_REVISED:
        return TimelineItem(event.id, et, "reliability", "Reliability changed", f"Evidence reliability changed from {_score(p.get('before_score'))} to {_score(p.get('final_score'))}.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.RELIABILITY_REAFFIRMED:
        return TimelineItem(event.id, et, "reliability", "Reliability unchanged", f"The evidence was reviewed again and remained at {_score(p.get('final_score'))}.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.SOURCE_VERIFICATION_ASSESSED:
        return TimelineItem(event.id, et, "source", "Source checked", f"Source verification result: {p.get('final_status', 'UNVERIFIED')}.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.SOURCE_VERIFICATION_REVISED:
        return TimelineItem(event.id, et, "source", "Source verification changed", f"Source verification changed from {p.get('before_status', 'UNKNOWN')} to {p.get('final_status', 'UNKNOWN')}.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.SOURCE_VERIFICATION_REAFFIRMED:
        return TimelineItem(event.id, et, "source", "Source verification unchanged", f"The source was checked again and remained {p.get('final_status', 'UNKNOWN')}.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.JUDGMENT_CREATED:
        return TimelineItem(event.id, et, "judgment", "Initial judgment created", f"Current conclusion: {p.get('conclusion', 'UNKNOWN')} ({_score(p.get('confidence'))} confidence).", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.JUDGMENT_REVISED:
        trigger = p.get("trigger", "UNKNOWN")
        return TimelineItem(event.id, et, "judgment", "Judgment changed", f"The judgment changed to {p.get('conclusion', 'UNKNOWN')} after {trigger}.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.JUDGMENT_REAFFIRMED:
        trigger = p.get("trigger", "UNKNOWN")
        return TimelineItem(event.id, et, "judgment", "Judgment maintained", f"The case was reviewed after {trigger}, but the current conclusion was maintained.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.JUDGMENT_FAILED:
        return TimelineItem(event.id, et, "judgment", "AI judgment failed", f"The AI provider did not produce a usable judgment ({p.get('error_code', 'UNKNOWN_ERROR')}).", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.AI_CALL_SKIPPED:
        return TimelineItem(event.id, et, "cost", "AI call skipped", "Nothing relevant changed, so the existing judgment was reused without a paid AI call.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.PERMISSION_CHANGED:
        return TimelineItem(event.id, et, "permission", "Execution permission changed", "The allowed action policy for this case was updated.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.ACTION_COMPLETED:
        return TimelineItem(event.id, et, "action", "Action completed", f"Action {p.get('action_type', '')} completed.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.ACTION_BLOCKED:
        return TimelineItem(event.id, et, "action", "Action blocked", f"Action was blocked: {p.get('blocked_reason', 'UNKNOWN')}.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.ACTION_FAILED:
        return TimelineItem(event.id, et, "action", "Action failed", "An allowed action was attempted but did not complete.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.CONTEXT_ASSESSED:
        return TimelineItem(event.id, et, "support", "Context reviewed", "The message context was reviewed for response support needs.", event.entity_type, event.entity_id, event.created_at)
    if et == HistoryEventType.NUDGE_GENERATED:
        return TimelineItem(event.id, et, "support", "Support recommendation prepared", f"A {p.get('nudge_level', 'support')} recommendation was prepared.", event.entity_type, event.entity_id, event.created_at)

    # Keep uncommon audit events visible rather than silently losing them.
    return TimelineItem(event.id, et, "system", et.value.replace("_", " ").title(), "A system event was recorded.", event.entity_type, event.entity_id, event.created_at)


def build_user_timeline(events: list[HistoryEvent]) -> list[TimelineItem]:
    items: list[TimelineItem] = []
    for event in events:
        item = _to_item(event)
        if item is None:
            continue

        if items:
            previous = items[-1]
            if (
                previous.event_type == item.event_type
                and previous.entity_type == item.entity_type
                and previous.entity_id == item.entity_id
                and previous.summary == item.summary
            ):
                previous.event_id = item.event_id
                previous.occurred_at = item.occurred_at
                previous.event_count += 1
                continue
        items.append(item)
    return items
