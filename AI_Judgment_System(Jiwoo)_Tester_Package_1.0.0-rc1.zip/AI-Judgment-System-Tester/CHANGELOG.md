# Changelog

## 1.0.0-rc1 — Step 14

- Added deployment readiness and system status endpoints.
- Added explicit opt-in one-call OpenAI live smoke test.
- Added paid-call cost caps: output token limit, low reasoning default, maximum input characters, and maximum evidence count.
- Added Docker / Compose files for app + PostgreSQL.
- Added GitHub Actions regression workflow.
- Preserved no-cost health/status behavior.
- Verified 67 automated tests plus local HTTP smoke checks.

## Step 13

- Added browser UI for the core Case / Evidence / Judgment / Timeline flow.
