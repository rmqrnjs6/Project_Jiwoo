# AI Judgment System — 처음 테스트하는 사람용 안내

## 목적

이 파일은 개발 지식이 많지 않아도 AI Judgment System을 직접 실행하고 테스트할 수 있도록 만든 안내서입니다.

현재 버전:

```text
1.0.0-rc1
```

---

# 1. 먼저 알아둘 것

## API Key 없이 가능한 테스트

다음 기능은 OpenAI API 비용 없이 테스트할 수 있습니다.

- Case 만들기
- Evidence 추가
- Evidence 신뢰도 평가
- 출처 상태 확인
- History 확인
- Timeline 확인
- 중복 Evidence 처리
- 각종 입력 검증

## 실제 AI 판단

`AI 판단`은 본인의 OpenAI API Key와 API 크레딧이 있어야 실제로 작동합니다.

중요:

```text
API Key 등록
→ 비용 없음

서버 실행
→ 비용 없음

AI 판단 버튼을 눌러 실제 OpenAI 요청 발생
→ 비용 발생 가능
```

본인의 API Key를 다른 사람에게 보내거나 공유하지 마세요.

---

# 2. Windows에서 실행하는 가장 쉬운 방법

프로젝트 폴더 안의:

```text
START_WINDOWS.bat
```

을 더블클릭하세요.

처음 실행할 때는 Python 패키지를 설치하므로 시간이 조금 걸릴 수 있습니다.

설치와 서버 시작이 끝나면 브라우저에서:

```text
http://127.0.0.1:8000/
```

을 엽니다.

서버를 끄고 싶다면 실행 중인 검은 창에서:

```text
Ctrl + C
```

를 누릅니다.

---

# 3. START_WINDOWS.bat이 안 될 경우

Python 3.12 설치를 권장합니다.

PowerShell을 열고 프로젝트의 `backend` 폴더에서:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

브라우저:

```text
http://127.0.0.1:8000/
```

---

# 4. 가장 쉬운 첫 테스트

## Case 만들기

예시:

### 제목

```text
신제품 출시 테스트
```

### 원본 입력

```text
A 회사가 내년에 새로운 제품을 출시할 것이다.
```

`새 Case 만들기`를 누릅니다.

---

# 5. Evidence 추가

근거 내용 예시:

```text
A 회사는 아직 해당 신제품 출시를 공식 발표하지 않았다.
```

출처 유형은 잘 모르겠으면:

```text
UNKNOWN
```

으로 두어도 됩니다.

그리고:

```text
Evidence 추가
```

를 누릅니다.

---

# 6. 신뢰도 평가

등록된 Evidence가 보이면:

```text
신뢰도 전체 평가
```

를 눌러봅니다.

예:

```text
0.34
0.68
```

같은 숫자가 보일 수 있습니다.

숫자가 높을수록 현재 시스템 기준에서 더 신뢰할 만한 Evidence로 평가되었다는 뜻입니다.

주의:

> 신뢰도 점수는 절대적인 진실 확률이 아닙니다.

---

# 7. AI Key가 없는 경우

화면에:

```text
AI 키 미설정
```

이라고 보이면 정상입니다.

이 상태에서는 실제 OpenAI 판단 버튼이 비활성화됩니다.

다른 기능은 계속 테스트할 수 있습니다.

---

# 8. 실제 AI 판단을 테스트하고 싶은 경우

본인의 OpenAI API Key가 있는 경우에만 진행하세요.

서버를 `Ctrl + C`로 종료합니다.

PowerShell:

```powershell
$env:OPENAI_API_KEY="본인의 키"
```

주의:

```text
키를 이 문서나 채팅창에 붙이지 마세요.
```

그 다음 서버를 다시 실행합니다.

```powershell
python -m uvicorn app.main:app --reload
```

또는 가상환경 Python:

```powershell
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

브라우저를 새로고침합니다.

---

# 9. 꼭 시험해볼 시나리오

## A. 근거 부족

입력:

```text
A 회사가 내년에 신제품을 출시할 것이다.
```

Evidence:

```text
아직 공식 발표는 없다.
```

확인하고 싶은 것:

```text
PENDING
또는
INSUFFICIENT_EVIDENCE
```

같은 불확실한 판단을 제대로 표현하는지.

---

## B. 새 Evidence에 따른 판단 변화

처음:

```text
공식 발표 없음
```

나중에 새 Evidence:

```text
A 회사가 공식 홈페이지에서 신제품 출시를 발표했다.
```

확인:

```text
이전 판단
↓
새 Evidence
↓
새 판단
```

Timeline에서 변화가 이해되게 표시되는지 봅니다.

---

## C. 같은 판단 유지

같은 조건에서 다시 검토했는데 결과가 그대로라면:

```text
REVISED
```

가 아니라:

```text
REAFFIRMED
```

의 의미로 표시되는지 확인합니다.

---

## D. 중복 Evidence

같은 Evidence를 똑같이 두 번 넣어봅니다.

시스템이 동일한 근거를 무한히 새 Evidence로 쌓지 않는지 확인합니다.

---

## E. 비용 방어

AI 판단을 한 뒤 입력·Evidence·규칙이 아무것도 변하지 않은 상태에서 다시 일반 판단을 요청합니다.

시스템이 가능하면 기존 Judgment를 재사용하여 불필요한 새 OpenAI 호출을 피하는지 확인합니다.

---

# 10. 테스트하면서 이상하다고 느껴지면

버그인지 확실하지 않아도 괜찮습니다.

다음 형식으로 적어주세요.

```text
무엇을 하려고 했나:
-

실제로 무엇을 눌렀나:
-

기대했던 결과:
-

실제 결과:
-

이상하다고 느낀 이유:
-

오류 문구가 있다면:
-
```

`TEST_FEEDBACK.md` 파일에 그대로 작성해도 됩니다.

---

# 11. 테스트할 때 가장 중요한 것

정답을 맞히려고 테스트하지 않아도 됩니다.

오히려 다음처럼 사용해보세요.

- 같은 버튼 여러 번 누르기
- 잘못된 값을 넣기
- 같은 Evidence 두 번 넣기
- 서로 반대되는 Evidence 넣기
- 출처를 모르는 상태로 넣기
- 새 Evidence를 추가한 뒤 이전 판단이 어떻게 변하는지 보기

> **사용자가 이상하게 사용할 때도 시스템이 이해 가능한 방식으로 반응하는지가 중요한 테스트입니다.**

---

# 12. 개인정보 주의

테스트 목적으로 실제 민감정보를 넣지 않는 것을 권장합니다.

예:

- 주민등록번호
- 실제 비밀번호
- API Key
- 카드번호
- 비공개 회사 문서
- 타인의 민감한 개인정보

샘플 문장이나 공개 자료로 테스트하세요.

---

# 13. 테스트 종료

서버가 실행 중인 터미널에서:

```text
Ctrl + C
```

를 누르면 종료됩니다.

로컬 테스트 데이터는 기본 SQLite DB에 남을 수 있습니다.

초기화가 필요하면 개발자에게 문의하세요.

---

## 한 줄 요약

```text
START_WINDOWS.bat 실행
→ http://127.0.0.1:8000 접속
→ Case 생성
→ Evidence 추가
→ 신뢰도 평가
→ Timeline 확인
→ API Key가 있는 사람만 실제 AI 판단
```
