# Security Notes

This repository is currently intended for private development.

- Never commit `OPENAI_API_KEY`, `.env`, database files, or production credentials.
- The current release candidate does **not** implement end-user authentication or ownership isolation. Do not expose it as a public multi-user service until that is added.
- Permission / Action rules are application-level controls and are not a substitute for authentication.
- Keep production databases and secrets outside the source tree.
- Treat external source-verification results as bounded evidence, not absolute proof.
