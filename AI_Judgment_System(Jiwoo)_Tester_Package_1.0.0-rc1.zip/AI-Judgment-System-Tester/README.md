# AI Judgment System — 1.0.0-rc1

> **완벽을 증명하는 시스템이 아니라, 변화할 수 있음을 증명하는 시스템.**
>
> **행위 권한 없는 지능은 결국 조언에 머문다.**

AI Judgment System is an experimental evidence-driven judgment system that preserves how a conclusion was formed, allows later evidence to trigger reevaluation, separates judgment from execution permission, and avoids unnecessary paid AI calls when nothing relevant changed.

## Current release candidate

The current scope has reached its first completion line (`1.0.0-rc1`). Core flows available in the browser:

1. Create a Case
2. Add Evidence
3. Assess Evidence reliability
4. Review source-verification state
5. Request an AI Judgment when configured
6. Reevaluate after meaningful changes
7. Reuse an unchanged Judgment without another paid call
8. View human-readable Timeline and raw History
9. Keep execution behind explicit Permission / Action rules

## Run locally

Recommended: Python 3.12.

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m uvicorn app.main:app --reload
```

Open:

```text
http://127.0.0.1:8000/
```

Swagger:

```text
http://127.0.0.1:8000/docs
```

## OpenAI configuration

OpenAI is optional for the non-AI parts of the application.

```text
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5.6-luna
OPENAI_TIMEOUT_SECONDS=30
OPENAI_MAX_RETRIES=1
OPENAI_MAX_OUTPUT_TOKENS=1800
OPENAI_REASONING_EFFORT=low
OPENAI_MAX_INPUT_CHARS=50000
OPENAI_MAX_EVIDENCE_ITEMS=25
```

`gpt-5.6-luna` is used as the default cost-sensitive model. The judgment request uses structured output, disables API response storage (`store=False`), caps output tokens, defaults to low reasoning effort, and blocks oversized inputs before a paid request is sent.

### Paid live smoke test

Normal tests never make a paid OpenAI call. The live smoke test requires explicit opt-in:

```powershell
$env:OPENAI_API_KEY="..."
$env:RUN_PAID_OPENAI_SMOKE_TEST="YES"
python scripts/live_openai_smoke_test.py
```

It sends exactly one judgment request.

## Operational checks

Free/local checks:

```text
GET /health
GET /ready
GET /system/status
GET /ai/status
```

`/ready` checks the database but does not call OpenAI.

## Test

```bash
cd backend
python -m pytest -q
```

The automated test count is recorded in `docs/test-results-step14.txt` after release verification.

## Docker

```bash
docker compose up --build
```

This starts the application with PostgreSQL. Keep secrets in environment variables; never commit `.env`.

## Current architecture principles

- Input is the claim being evaluated, not evidence.
- Evidence provenance and verification state are preserved separately.
- Judgment is a current position, not a declaration of eternal truth.
- `PENDING`, `UNRESOLVED`, and `RESOLVED` are distinct.
- Reassessment and actual change are distinct (`REAFFIRMED` vs `REVISED`).
- History preserves meaningful changes; Timeline summarizes them for humans.
- Decision Snapshot records what the system saw at judgment time.
- Cost Guard reuses an unchanged AI judgment rather than spending another call.
- Judgment, Permission, and Action remain separate.

## Known post-RC work

This RC is not presented as a finished high-scale production platform. Important follow-up work includes authentication/ownership, stronger concurrency controls, Grace Period automation, semantic evidence cross-checking, stronger external source verification, production-grade DB migrations, and operational monitoring.

See `docs/step14-release-candidate.md` for the release boundary.
