# 실제 AI 판단을 테스트하는 방법

이 단계는 선택 사항입니다.

## 비용 관련

다음은 비용이 발생하지 않습니다.

```text
API Key를 환경변수로 등록
서버 실행
화면 접속
Case/Evidence/Timeline 사용
```

실제 OpenAI 모델 요청이 발생하면 비용이 발생할 수 있습니다.

## Windows PowerShell

서버를 먼저 `Ctrl + C`로 종료한 뒤:

```powershell
$env:OPENAI_API_KEY="본인의 API Key"
```

그 다음:

```powershell
cd backend
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

브라우저를 새로고침하세요.

## 절대 하지 말 것

- API Key를 채팅에 올리기
- API Key를 GitHub에 commit하기
- 다른 사람의 키를 이 패키지에 저장하기

테스트가 끝난 뒤 현재 PowerShell 세션에서 키를 지우려면:

```powershell
Remove-Item Env:OPENAI_API_KEY
```
