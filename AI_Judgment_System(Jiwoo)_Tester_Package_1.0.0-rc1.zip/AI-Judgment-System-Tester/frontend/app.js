const state = { cases: [], currentCaseId: null, currentCase: null, ai: null };

const $ = (id) => document.getElementById(id);

function showToast(message, isError = false) {
  const el = $("toast");
  el.textContent = message;
  el.className = `toast${isError ? " error" : ""}`;
  setTimeout(() => el.classList.add("hidden"), 3500);
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  const body = response.status === 204 ? null : await response.json().catch(() => null);
  if (!response.ok) {
    const detail = body?.detail;
    const message = typeof detail === "string" ? detail : detail?.message || detail?.code || `HTTP ${response.status}`;
    const error = new Error(message);
    error.status = response.status;
    error.body = body;
    throw error;
  }
  return { body, status: response.status };
}

function formatDate(value) {
  if (!value) return "-";
  return new Intl.DateTimeFormat("ko-KR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value));
}

async function loadAiStatus() {
  try {
    const { body } = await api("/ai/status");
    state.ai = body;
    const el = $("aiStatus");
    if (body.configured) {
      el.textContent = `AI 준비됨 · ${body.model}`;
      el.className = "status-pill good";
    } else {
      el.textContent = "AI 키 미설정";
      el.className = "status-pill warn";
    }
    updateJudgeAvailability();
  } catch (error) {
    $("aiStatus").textContent = "AI 상태 확인 실패";
  }
}

async function loadCases(selectId = null) {
  const { body } = await api("/cases");
  state.cases = body;
  renderCaseList();
  if (selectId) await selectCase(selectId);
}

function renderCaseList() {
  const host = $("caseList");
  if (!state.cases.length) {
    host.innerHTML = '<div class="muted-box">아직 Case가 없습니다.</div>';
    return;
  }
  host.innerHTML = state.cases.map(item => `
    <button class="case-item ${item.id === state.currentCaseId ? "active" : ""}" data-id="${item.id}">
      ${escapeHtml(item.title)}
      <small>#${item.id} · ${item.status} · ${formatDate(item.created_at)}</small>
    </button>
  `).join("");
  host.querySelectorAll(".case-item").forEach(button => {
    button.addEventListener("click", () => selectCase(Number(button.dataset.id)));
  });
}

async function selectCase(caseId) {
  state.currentCaseId = caseId;
  const { body } = await api(`/cases/${caseId}`);
  state.currentCase = body;
  renderCaseList();
  renderCase(body);
  await loadTimeline();
}

function renderCase(data) {
  $("emptyState").classList.add("hidden");
  $("caseView").classList.remove("hidden");
  $("caseViewTitle").textContent = data.title;
  $("caseStatus").textContent = data.status;
  $("caseOriginalInput").textContent = data.original_input;
  renderEvidence(data.evidence || []);
  renderLatestJudgment(data.judgments || []);
  updateJudgeAvailability();
}

function renderEvidence(items) {
  const host = $("evidenceList");
  if (!items.length) {
    host.innerHTML = '<div class="muted-box">등록된 Evidence가 없습니다.</div>';
    return;
  }
  host.innerHTML = items.map(item => `
    <article class="evidence-card">
      <p><strong>#${item.id}</strong> ${escapeHtml(item.content)}</p>
      <div class="meta-row">
        <span class="meta-chip">주장 출처: ${item.claimed_source_type}</span>
        <span class="meta-chip">검증: ${item.source_verification_status}</span>
        <span class="meta-chip">신뢰도: ${item.reliability_score == null ? "미평가" : Math.round(item.reliability_score * 100) + "%"}</span>
        <span class="meta-chip">${escapeHtml(item.reliability_source)}</span>
      </div>
      ${item.source_url ? `<a href="${escapeAttr(item.source_url)}" target="_blank" rel="noreferrer">출처 열기</a>` : ""}
      <div class="evidence-actions">
        <button class="ghost reliability-one" data-id="${item.id}">신뢰도 평가</button>
        <button class="ghost verify-one" data-id="${item.id}">출처 형식 확인</button>
      </div>
    </article>
  `).join("");
  host.querySelectorAll(".reliability-one").forEach(button => button.addEventListener("click", () => assessOne(Number(button.dataset.id))));
  host.querySelectorAll(".verify-one").forEach(button => button.addEventListener("click", () => verifyOne(Number(button.dataset.id))));
}

function renderLatestJudgment(items) {
  const latest = [...items].sort((a, b) => b.revision_no - a.revision_no)[0];
  if (!latest) {
    $("judgmentEmpty").classList.remove("hidden");
    $("judgmentView").classList.add("hidden");
    return;
  }
  $("judgmentEmpty").classList.add("hidden");
  $("judgmentView").classList.remove("hidden");
  $("judgmentConclusion").textContent = latest.conclusion;
  $("judgmentConfidence").textContent = `${Math.round(latest.confidence * 100)}%`;
  $("judgmentPosition").textContent = latest.position_text;
  $("judgmentReason").textContent = latest.reasoning_summary;
  $("judgmentMeta").innerHTML = [
    `Revision ${latest.revision_no}`,
    latest.resolution_state,
    latest.reevaluation_trigger || "INITIAL",
    latest.origin,
  ].map(value => `<span class="meta-chip">${escapeHtml(String(value))}</span>`).join("");
}

async function loadTimeline() {
  if (!state.currentCaseId) return;
  const { body } = await api(`/cases/${state.currentCaseId}/timeline`);
  const host = $("timeline");
  if (!body.length) {
    host.innerHTML = '<div class="muted-box">표시할 이력이 없습니다.</div>';
    return;
  }
  host.innerHTML = body.map(item => `
    <article class="timeline-item">
      <h3>${escapeHtml(item.title)}</h3>
      <p>${escapeHtml(item.summary)}</p>
      <time>${formatDate(item.occurred_at)} · ${item.event_type}${item.event_count > 1 ? ` · ${item.event_count}건` : ""}</time>
    </article>
  `).join("");
}

function updateJudgeAvailability() {
  const noEvidence = !state.currentCase?.evidence?.length;
  const noAi = !state.ai?.configured;
  $("judgeButton").disabled = noEvidence || noAi;
  $("forceJudgeButton").disabled = noEvidence || noAi;
  if (noAi) $("judgeMessage").textContent = "실제 AI 판단을 실행하려면 OPENAI_API_KEY가 필요합니다.";
  else if (noEvidence) $("judgeMessage").textContent = "Evidence를 먼저 추가하세요.";
  else $("judgeMessage").textContent = "변화가 없으면 기존 판단을 재사용해 비용을 아낍니다.";
}

async function refreshCurrentCase() {
  if (state.currentCaseId) await selectCase(state.currentCaseId);
}

async function assessOne(evidenceId) {
  try {
    await api(`/cases/${state.currentCaseId}/evidence/${evidenceId}/assess-reliability`, { method: "POST" });
    showToast(`Evidence #${evidenceId} 신뢰도를 평가했습니다.`);
    await refreshCurrentCase();
  } catch (error) { showToast(error.message, true); }
}

async function verifyOne(evidenceId) {
  try {
    const { body } = await api(`/cases/${state.currentCaseId}/evidence/${evidenceId}/verify-source`, { method: "POST" });
    showToast(`출처 확인 결과: ${body.status}`);
    await refreshCurrentCase();
  } catch (error) { showToast(error.message, true); }
}

async function runJudge(force = false) {
  if (!state.currentCaseId) return;
  const button = force ? $("forceJudgeButton") : $("judgeButton");
  button.disabled = true;
  $("judgeMessage").textContent = force ? "강제 재판단 중..." : "판단 중...";
  try {
    const { status } = await api(`/cases/${state.currentCaseId}/judge${force ? "?force=true" : ""}`, { method: "POST" });
    showToast(status === 200 ? "변화가 없어 기존 판단을 재사용했습니다. API 비용을 쓰지 않았습니다." : "새 Judgment를 생성했습니다.");
    await refreshCurrentCase();
  } catch (error) {
    const code = error.body?.detail?.code;
    showToast(code ? `${code}: ${error.message}` : error.message, true);
    await loadTimeline().catch(() => {});
  } finally {
    updateJudgeAvailability();
  }
}

$("caseForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const { body } = await api("/cases", {
      method: "POST",
      body: JSON.stringify({ title: $("caseTitle").value, original_input: $("caseInput").value }),
    });
    event.target.reset();
    showToast("Case를 만들었습니다.");
    await loadCases(body.id);
  } catch (error) { showToast(error.message, true); }
});

$("evidenceForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const sourceUrl = $("sourceUrl").value.trim();
    await api(`/cases/${state.currentCaseId}/evidence`, {
      method: "POST",
      body: JSON.stringify({
        content: $("evidenceContent").value,
        source_type: $("sourceType").value,
        source_url: sourceUrl || null,
        is_primary_source: $("isPrimary").checked,
        reliability_score: null,
      }),
    });
    event.target.reset();
    showToast("Evidence를 추가했습니다.");
    await refreshCurrentCase();
  } catch (error) {
    if (error.status === 409 && error.body?.detail?.code === "DUPLICATE_EVIDENCE") {
      showToast(`이미 등록된 Evidence입니다. 기존 ID: ${error.body.detail.existing_evidence_id}`, true);
    } else showToast(error.message, true);
  }
});

$("assessAllButton").addEventListener("click", async () => {
  try {
    await api(`/cases/${state.currentCaseId}/assess-reliability`, { method: "POST" });
    showToast("전체 Evidence 신뢰도를 평가했습니다.");
    await refreshCurrentCase();
  } catch (error) { showToast(error.message, true); }
});

$("judgeButton").addEventListener("click", () => runJudge(false));
$("forceJudgeButton").addEventListener("click", () => runJudge(true));
$("refreshTimeline").addEventListener("click", () => loadTimeline().catch(error => showToast(error.message, true)));
$("refreshCases").addEventListener("click", () => loadCases().catch(error => showToast(error.message, true)));

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char]);
}
function escapeAttr(value) { return escapeHtml(value); }

Promise.all([loadAiStatus(), loadCases()]).catch(error => showToast(error.message, true));
