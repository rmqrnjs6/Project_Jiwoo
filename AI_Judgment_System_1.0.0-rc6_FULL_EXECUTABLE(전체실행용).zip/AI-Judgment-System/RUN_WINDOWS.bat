﻿@echo off
setlocal
chcp 65001 >nul
title AI Judgment System

cd /d "%~dp0"

echo ==========================================
echo      AI Judgment System - Windows Run
echo ==========================================
echo.

if not exist "backend\requirements.txt" (
    echo [ERROR] backend\requirements.txt 파일을 찾을 수 없습니다.
    echo 이 BAT 파일을 AI-Judgment-System 최상위 폴더에 넣어주세요.
    echo.
    pause
    exit /b 1
)

if not exist ".env" (
    if exist ".env.example" (
        copy /y ".env.example" ".env" >nul
        echo [INFO] .env 파일을 생성했습니다.
        echo        OpenAI API를 사용할 경우 .env의 OPENAI_API_KEY를 입력하세요.
        echo.
    )
)

if not exist "backend\.venv\Scripts\python.exe" (
    echo [1/3] Python 가상환경을 생성합니다...

    where py >nul 2>nul
    if %errorlevel%==0 (
        py -3.12 -m venv "backend\.venv"
    ) else (
        where python >nul 2>nul
        if not %errorlevel%==0 (
            echo [ERROR] Python을 찾을 수 없습니다.
            echo Python 3.12를 설치한 뒤 다시 실행해주세요.
            echo.
            pause
            exit /b 1
        )
        python -m venv "backend\.venv"
    )

    if not exist "backend\.venv\Scripts\python.exe" (
        echo [ERROR] 가상환경 생성에 실패했습니다.
        pause
        exit /b 1
    )

    echo [2/3] 필요한 패키지를 설치합니다...
    "backend\.venv\Scripts\python.exe" -m pip install --upgrade pip
    if errorlevel 1 goto :install_error

    "backend\.venv\Scripts\python.exe" -m pip install -r "backend\requirements.txt"
    if errorlevel 1 goto :install_error
) else (
    echo [1/3] 기존 Python 가상환경을 사용합니다.
    echo [2/3] 패키지 설치를 건너뜁니다.
)

echo [3/3] 서버를 시작합니다.
echo.
echo Browser : http://127.0.0.1:8000/
echo API Docs : http://127.0.0.1:8000/docs
echo.
echo 서버를 종료하려면 이 창에서 Ctrl+C 를 누르세요.
echo ==========================================
echo.

start "" cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:8000/"

pushd "backend"
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000
set RUN_RESULT=%errorlevel%
popd

echo.
if not "%RUN_RESULT%"=="0" (
    echo [ERROR] 서버가 종료되었습니다. 오류 내용을 확인해주세요.
) else (
    echo 서버가 종료되었습니다.
)
pause
exit /b %RUN_RESULT%

:install_error
echo.
echo [ERROR] Python 패키지 설치에 실패했습니다.
echo 인터넷 연결과 requirements.txt 내용을 확인해주세요.
pause
exit /b 1
