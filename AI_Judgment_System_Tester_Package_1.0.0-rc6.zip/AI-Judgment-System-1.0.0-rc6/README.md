# AI Judgment System — 1.0.0-rc6

> **완벽을 증명하는 시스템이 아니라, 변화할 수 있음을 증명하는 시스템.**
>
> **행위 권한 없는 지능은 결국 조언에 머문다.**

AI Judgment System은 사용자의 주장을 하나의 Case로 관리하고, 관련 근거를 검토한 뒤 현재 판단을 만들며, 새로운 근거가 생겼을 때 판단이 어떻게 유지되거나 바뀌었는지를 기록하는 실험적 판단 시스템입니다.

## RC6 핵심 변화 — 현재 확인된 핵심과 공유 가능한 기억

이번 RC6에서는 프로젝트의 사용자 가치를 UI 중심에 배치했습니다.

> **흩어진 의혹과 논란 속에서 현재 가장 명확하게 확인된 범위를 정리하고, 사용자가 정보 확인에 쓰는 부담을 줄이는 것.**

새로운 `현재 확인된 핵심` 패널은 다음을 한 화면에서 보여줍니다.

- 현재 확인 결과를 사람말로 요약
- 지금 확인된 범위
- 아직 확인이 필요한 부분
- 현재 상태: 정리됨 / 기다림 / 아직 열려 있음
- 더 깊게 볼 필요가 있는지 판단할 수 있는 짧은 안내

또한 `공유용 요약 복사`를 추가했습니다. 이 기능은 **새 API 호출 없이** 현재 Case의 확인 결과, 남은 불확실성, 채택된 대표 근거의 출처와 URL, 확인 시점을 공유 가능한 텍스트로 묶습니다.

대중 UI에서는 `판단 관리` 대신 `확인하기`, `판단 목록` 대신 `확인 목록`처럼 더 일반적인 언어를 사용합니다. 내부 Judgment / History 구조는 그대로 유지합니다.

제품의 외부 가치 문장은 다음과 같습니다.

> **확인에 쓰는 시간을 줄이고, 살아가는 데 쓰는 시간을 늘립니다.**

자세한 내용은 `docs/step19-clarity-stress-reduction-sharing.md`를 참고하세요.

## RC5 핵심 변화 — 친근함과 기억의 UX

이번 RC5는 기능을 더 늘리는 대신, 사용자가 시스템을 **차분하고 솔직하게 함께 확인해주는 존재**로 느낄 수 있도록 표현 계층을 다듬었습니다.

- `추천 근거` → `함께 볼 근거`
- `현재 가장 신뢰할 만한 근거` → `지금 가장 믿을 만한 근거`
- `변화 이력` → `함께 확인한 기록`
- 판단 전 상태는 `아직 결론을 서두르지 않았어요.`로 표현
- Timeline의 기술적인 영어 문구를 사람이 읽기 쉬운 한국어 서술형으로 변경
- Judgment의 revision / resolution / trigger를 기본 화면에서는 사람말로 번역
- 친근함을 캐릭터성보다 **일관된 태도, 여백, 솔직한 불확실성 표현**으로 구현

Raw History와 판단 구조 자체는 변경하지 않았습니다. 표현 계층만 사람 중심으로 개선했습니다.

자세한 내용은 `docs/step18-friendly-memory-ux.md`를 참고하세요.

## RC4 핵심 변화 — 사람 중심 Evidence Review

이번 RC4에서는 RC2의 추천 근거 구조를 유지하면서, 사용자가 기술 용어를 몰라도 바로 검수할 수 있도록 Evidence UI를 다시 단순화했습니다.

기존 흐름:

```text
사용자가 근거를 직접 입력
→ 신뢰도 평가
→ AI 판단
```

새 흐름:

```text
Case 생성
→ AI가 공개 웹에서 5~10개의 근거 후보 제안
→ 출처 / 링크 / 핵심 내용 / 신뢰도 %를 한 화면에서 확인
→ 현재 후보 중 대표 근거 1개 자동 강조
→ 사용자가 필요한 근거를 채택
→ 채택된 근거만 AI 판단에 사용
```

### 대표 근거

추천 후보 중 현재 평가가 가장 높은 **한 개만 `현재 대표 근거`**로 표시됩니다.

대표 근거 점수는 최대 99%로 제한되어 있습니다. 이 점수는 `사실일 확률`이 아니라 현재 확인된 다음 요소를 조합한 **신뢰도 평가값**입니다.

- 출처 권위성
- 원본성
- 직접성
- 최신성
- 독립 근거와의 교차검토

따라서 `94%`는 “94% 확률로 사실”이라는 뜻이 아닙니다.

## 근거를 바로 읽는 방식

추천 근거 카드는 링크만 보여주지 않습니다.

각 카드에서 바로 확인할 수 있습니다.

- 출처 이름
- 원문 URL
- 게시일
- 주장과의 관계
- AI가 출처를 바탕으로 만든 핵심 요약
- 신뢰도 %
- 신뢰도 세부 계산
- 대표 근거 여부

원문 확인이 필요할 때만 `원문 보기`를 누르면 됩니다.

## 실행

Python 3.12 권장.

Windows에서는 프로젝트 루트의:

```text
START_WINDOWS.bat
```

을 실행하면 됩니다.

직접 실행:

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

브라우저:

```text
http://127.0.0.1:8000/
```

API 문서:

```text
http://127.0.0.1:8000/docs
```

## API Key 없이 테스트

API Key가 없어도 다음은 테스트할 수 있습니다.

- Case 생성
- 새 UI 탐색
- `예시 보기` 버튼으로 추천 근거 5~10개 UI 확인
- 대표 근거 1개 자동 선정 확인
- 신뢰도 % 및 세부 계산 펼치기
- 후보 근거 채택 흐름
- History / Timeline
- 직접 Evidence 추가

`예시 보기`의 후보는 **실제 근거가 아닙니다.** 데모로 채택한 Evidence는 `DEMO_CANDIDATE`로 표시되고 실제 AI 판단에 사용할 수 없도록 차단됩니다.

## 실제 추천 근거 찾기

실제 공개 웹에서 근거 후보를 찾으려면 OpenAI API Key가 필요합니다.

```powershell
$env:OPENAI_API_KEY="본인의_API_Key"
```

그 뒤 서버를 시작하고 `근거 찾기`를 누릅니다.

이 기능은 OpenAI Responses API의 웹 검색 도구를 사용하므로 **실제 API 비용이 발생할 수 있습니다.**

현재 후보는 자동으로 Evidence가 되지 않습니다. 사용자가 `판단에 사용`을 눌러야 실제 Judgment 입력에 포함됩니다.

### 관련 환경 변수

```text
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5.6-luna
OPENAI_EVIDENCE_MODEL=gpt-5.6-luna
OPENAI_TIMEOUT_SECONDS=30
OPENAI_MAX_RETRIES=1
OPENAI_MAX_OUTPUT_TOKENS=1800
OPENAI_EVIDENCE_MAX_OUTPUT_TOKENS=3600
OPENAI_REASONING_EFFORT=low
OPENAI_MAX_INPUT_CHARS=50000
OPENAI_MAX_EVIDENCE_ITEMS=25
```

## 기존 Judgment 흐름

- Input은 판단 대상이며 Evidence가 아닙니다.
- Judgment는 영구적인 진실이 아니라 현재 시점의 판단입니다.
- `SUPPORTED`, `CONTRADICTED`, `UNCERTAIN`, `INSUFFICIENT_EVIDENCE`를 구분합니다.
- `PENDING`, `UNRESOLVED`, `RESOLVED`를 구분합니다.
- 재검토 후 실제 변화가 있으면 `REVISED`, 유지되면 `REAFFIRMED`로 기록합니다.
- History는 원본 사건을 보존하고 Timeline은 사람이 읽기 쉽게 요약합니다.
- Judgment, Permission, Action은 분리됩니다.
- Decision Fingerprint가 같으면 Cost Guard가 기존 Judgment를 재사용합니다.

## 테스트 상태

2026-09-11 기준 로컬에서 실제 실행한 결과:

```text
77 passed
Python compileall: passed
JavaScript syntax check: passed
GET /health: 200
GET /ready: 200
GET /system/status: 200
GET /: 200
```

중요:

> `77 passed`는 작성된 자동 테스트 77개가 통과했다는 뜻이며, 제품 전체가 완벽하게 검증되었다는 뜻은 아닙니다.

실제 유료 OpenAI 웹 검색/판단 호출은 이 개발 환경에서 실행하지 않았습니다. 따라서 OpenAI Web Evidence Discovery는 구조 및 Mock 테스트까지 검증되었고, 실제 유료 계정에서의 최종 Live Test는 별도로 남아 있습니다.

## 현재 남은 검증/개선 항목

- 실제 OpenAI Web Evidence Discovery Live Test
- 추천된 URL의 도메인/문서 진위에 대한 더 강한 독립 검증
- Semantic source dependency 분석
- 동일 원출처를 재인용한 기사 군집 감지
- 사용자 인증 및 Case 소유권
- 동시성 제어
- PostgreSQL / Docker 실환경 통합 테스트
- 실제 사용자 장기 테스트

Evidence Workspace 구조는 `docs/step15-evidence-workspace.md`, 사람 중심 UI 변경은 `docs/step16-human-evidence-review.md`, 충돌 패널티 제거 결정은 `docs/step17-no-conflict-penalty.md`, 친근함과 기억의 UX는 `docs/step18-friendly-memory-ux.md`, 현재 확인된 핵심과 공유 UX는 `docs/step19-clarity-stress-reduction-sharing.md`를 참고하세요.


## RC4 사람 중심 표시 원칙

- 기본 화면에는 출처 이름, 핵심 내용, 날짜, 신뢰도 `% + 사람말`만 우선 표시합니다.
- `출처 형식 확인`은 별도 주요 버튼에서 제거했습니다. 출처 검사는 내부적으로 유지하며 문제가 있을 때만 경고합니다.
- `왜 이 점수인가요?`를 열면 권위성, 원본성, 직접 관련성, 자료 시점, 교차검토를 확인할 수 있습니다.
- 근거를 선택하거나 직접 추가했을 때 URL이 있으면 로컬 출처 점검을 자동으로 수행합니다. 이 과정은 OpenAI 유료 호출이 아닙니다.
- 대표 근거는 `지금 가장 믿을 만한 근거`로 표현하며, 새 자료가 들어오면 바뀔 수 있음을 항상 명시합니다.
