# Step 7 — Evidence Reliability Engine

## Goal

Make evidence reliability auditable instead of treating a single score as an unexplained truth.

## V1 reliability components

`metadata-v1` computes and stores:

- source authority
- originality / primary-source status
- directness proxy
- recency
- corroboration (neutral placeholder in metadata-v1)
- final weighted score
- method version
- rationale

The final score is written back to `Evidence.reliability_score` and tagged with
`Evidence.reliability_source`. Each assessment is append-only and receives a
`revision_no`.

## Important limitation

`metadata-v1` does **not** claim to understand whether two pieces of evidence are
semantically consistent or contradictory. Corroboration is held at a neutral
0.50 until a semantic cross-evidence provider is connected. This is intentional to avoid presenting lexical heuristics as fact
verification.

## History events

- `RELIABILITY_ASSESSED`
- `RELIABILITY_REVISED`

## API

- `POST /cases/{case_id}/evidence/{evidence_id}/assess-reliability`
- `POST /cases/{case_id}/assess-reliability`
- `GET /cases/{case_id}/evidence/{evidence_id}/reliability`

## Re-judgment integration

The judgment engine already reads `Evidence.reliability_score`. Therefore a
new evidence item can be reliability-assessed and then included in a new
judgment revision. The automated test suite includes a controlled provider test
where a higher-reliability new primary source changes a prior `SUPPORTED`
judgment to `CONTRADICTED` while preserving the previous judgment.

> Step 17 update: conflict penalty is no longer part of Reliability scoring. The legacy database column remains only for backward compatibility.
