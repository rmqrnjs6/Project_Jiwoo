# Step 15 — Evidence Workspace / RC2

## 목표

Evidence를 사용자가 처음부터 직접 작성하는 구조에서, AI가 공개 자료를 후보로 제시하고 사용자가 검수·판별한 뒤 채택하는 구조로 변경한다.

## 구현 범위

### 1. 추천 근거 후보

- 5~10개 요청 가능
- 기본 UI 요청 수: 6개
- 실제 모드: OpenAI Responses API + web search
- 데모 모드: 네트워크/유료 호출 없는 UX 테스트 데이터

### 2. 대표 근거 1개

각 추천 배치에서 신뢰도 평가가 가장 높은 후보 단 하나만 `is_representative=true`가 된다.

대표 근거는 사실 확정이 아니다. 현재 후보 집합에서 가장 강한 후보라는 뜻이다.

### 3. 후보 신뢰도

최종 점수:

```text
authority      30%
originality    22%
directness     22%
recency         8%
corroboration  18%
```

최종값은 0.99 이하로 제한한다.

### 4. Candidate와 Evidence 분리

발견된 웹 자료는 바로 Judgment Evidence가 되지 않는다.

```text
EvidenceCandidate
→ 사용자 검수
→ Adopt
→ Evidence
```

이 구조로 AI 검색 결과가 무조건 판단에 들어가는 것을 방지한다.

### 5. 바로 읽기

근거 카드에서 출처 링크 외에 AI 요약을 바로 표시한다.

- 출처
- URL
- 게시일
- AI 요약
- source type
- verification state
- relation to claim
- 신뢰도
- 세부 점수
- 평가 이유

### 6. 데모 안전장치

`데모로 체험`에서 나온 후보는 실제 Evidence로 채택해 UI 흐름을 시험할 수 있지만:

```text
reliability_source = DEMO_CANDIDATE
```

로 저장되며 `/judge`에서 실제 AI Judgment를 차단한다.

## API

```text
GET  /cases/{case_id}/evidence-candidates
POST /cases/{case_id}/evidence-candidates/discover
POST /cases/{case_id}/evidence-candidates/demo
POST /cases/{case_id}/evidence-candidates/{candidate_id}/adopt
```

## 테스트

실제 실행 결과:

```text
73 passed
```

추가 테스트는 다음을 검증한다.

- Evidence Workspace UI 문구/자산 제공
- 데모 후보 5~10개 생성
- 대표 근거 정확히 1개
- 점수 구성요소 노출
- 후보 채택 idempotency
- 데모 Evidence 실제 AI Judgment 차단
- API Key 미설정 실제 검색 차단
- OpenAI web_search 요청 구조(Mock)
- 100% 확정처럼 보이지 않도록 점수 0.99 상한

## Live Test 경계

OpenAI API 비용이 필요한 실제 웹 검색 호출은 개발 환경에서 실행하지 않았다.

> Step 17 update: conflict penalty was removed from candidate scoring. Opposing evidence remains visible as a relation/comparison signal rather than reducing source quality.
