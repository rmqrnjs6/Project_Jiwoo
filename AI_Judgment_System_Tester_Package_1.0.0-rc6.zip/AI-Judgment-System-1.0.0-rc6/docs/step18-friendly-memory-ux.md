# Step 18 — Calm, Friendly, Memory-Oriented UX

## Goal

사용자가 시스템을 기술 도구가 아니라 **함께 확인한 과정을 기억해주는 조용한 동반자**처럼 느낄 수 있도록 화면 언어와 Timeline을 정리했다.

## Principles

- 친근함을 귀여운 캐릭터나 과한 감정 표현으로 만들지 않는다.
- 사용자가 먼저 알아야 할 내용만 보여주고 기술 용어는 뒤로 보낸다.
- 모르는 것은 모른다고 말하고, 결론을 서두르지 않는다.
- 판단이 달라졌을 때 틀린 과거를 숨기지 않고 변화 이유를 기록한다.
- 사용자가 다시 돌아왔을 때 과거 작업이 단순 로그가 아니라 `함께 확인한 기록`으로 읽히게 한다.

## UI changes

- Brand subtitle: `함께 확인한 과정을 남깁니다`
- Empty state: `어떤 판단부터 같이 확인해볼까요?`
- `추천 근거` → `함께 볼 근거`
- Empty judgment: `아직 결론을 서두르지 않았어요.`
- Representative evidence: `지금 가장 믿을 만한 근거`
- Timeline: `함께 확인한 기록`
- `판단하기` → `현재 기준으로 판단하기`
- `다시 판단하기` → `새로 확인하기`
- technical revision/resolution/trigger values are translated into human-facing labels in the main UI.

## Timeline

기존 영어/감사 로그 중심 문구를 한국어 서술형 문장으로 바꿨다. Raw History는 변경하지 않는다.

예:

- `Initial judgment created` → `첫 판단을 정리했어요`
- `Judgment maintained` → `다시 확인했지만 판단은 같아요`
- `AI call skipped` → `달라진 게 없어 이전 판단을 이어갔어요`
- duplicate evidence → `같은 근거는 한 번만 반영했어요`

이 변경은 감사 데이터 자체가 아니라 User Timeline 표현 계층에만 적용된다.
