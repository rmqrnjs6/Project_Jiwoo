@echo off
setlocal
cd /d "%~dp0backend"

echo.
echo ==============================================
echo   AI Judgment System 1.0.0-rc6 - Step 19
echo ==============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python was not found.
    echo Install Python 3.12 and try again.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Creating local Python environment...
    python -m venv .venv
    if errorlevel 1 goto :error
)

echo [2/3] Installing/updating packages...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :error

echo [3/3] Starting server...
echo.
echo Open: http://127.0.0.1:8000/
echo Press Ctrl+C to stop.
echo.
".venv\Scripts\python.exe" -m uvicorn app.main:app --reload
goto :eof

:error
echo.
echo [ERROR] Setup or startup failed.
echo Copy the error message and share it with the developer.
pause
exit /b 1
