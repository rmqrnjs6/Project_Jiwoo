# Changelog

## 1.0.0-rc6 — Step 19

- Added `현재 확인된 핵심` as the primary human-facing summary for each Case.
- Added separate `지금 확인된 범위` and `아직 확인이 필요한 부분` blocks.
- Added calm resolution-state language: `현재 범위 정리됨`, `조금 더 기다려야 해요`, `아직 열려 있어요`.
- Added `공유용 요약 복사` with no additional OpenAI call.
- Share summary includes the current core, remaining uncertainty, adopted representative source when available, source URL, and confirmation time.
- Reframed public UI labels from judgment-centric wording to familiar verification wording while preserving the internal Judgment domain.
- Added the product promise `확인에 쓰는 시간을 줄이고, 살아가는 데 쓰는 시간을 늘립니다.`
- Added Step 19 regression tests.

## 1.0.0-rc5 — Step 18

- Added calm, friendly, memory-oriented product language without changing judgment semantics.
- Added brand subtitle `함께 확인한 과정을 남깁니다`.
- Reframed the empty state around starting a shared verification journey.
- Renamed core UI labels to human language: `함께 볼 근거`, `지금 가장 믿을 만한 근거`, `함께 확인한 기록`.
- Changed judgment actions to `현재 기준으로 판단하기` and `새로 확인하기`.
- Rewrote User Timeline messages in conversational Korean while preserving Raw History.
- Translated Judgment revision/resolution/trigger metadata into human-facing labels.
- Added regression tests for the friendly UI copy and human-readable Timeline.

## 1.0.0-rc4 — Step 17

- 사람 중심 Evidence Review UI
- `출처 형식 확인`을 주요 버튼에서 제거하고 자동 로컬 점검으로 전환
- 신뢰도 `%`에 `매우 높음 / 높음 / 보통 / 주의 / 낮음` 병기
- 출처 이상이 있을 때만 경고 표시
- `AI 요약` 대신 `핵심 내용`을 기본 표시하고 원문 링크 유지
- 상세 계산은 `왜 이 점수인가요?`로 접어서 제공
- `현재 대표 근거`를 `현재 가장 신뢰할 만한 근거`로 변경
- 채택/직접 추가 시 로컬 출처·신뢰도 점검 자동화
- 버튼과 라벨을 일반적인 표현으로 단순화

## 1.0.0-rc2 — Step 15

- Rebuilt the browser UI around a conventional evidence-review workspace.
- Added 5–10 evidence candidate discovery with optional OpenAI web search.
- Added a no-cost demo candidate mode for UX testing.
- Added exactly one current representative evidence candidate per recommendation batch.
- Added visible percentage-based reliability with component breakdowns and a hard 99% ceiling.
- Added source name, URL, publication date, AI summary, claim relationship, and verification status to recommendation cards.
- Separated discovered candidates from adopted Evidence; only user-adopted Evidence enters Judgment.
- Added demo-evidence guard so UX demo material can never be used for a real AI Judgment.
- Added evidence comparison view and collapsed manual Evidence entry.
- Added candidate discovery/adoption events to Timeline.
- Verified 73 automated tests, Python compilation, JavaScript syntax, and local HTTP smoke endpoints.
- Did not perform a paid OpenAI web-search live call in the development environment.

## 1.0.0-rc1 — Step 14

- Added deployment readiness and system status endpoints.
- Added explicit opt-in one-call OpenAI live smoke test.
- Added paid-call cost caps: output token limit, low reasoning default, maximum input characters, and maximum evidence count.
- Added Docker / Compose files for app + PostgreSQL.
- Added GitHub Actions regression workflow.
- Preserved no-cost health/status behavior.
- Verified 67 automated tests plus local HTTP smoke checks.

## Step 13

- Added browser UI for the core Case / Evidence / Judgment / Timeline flow.
