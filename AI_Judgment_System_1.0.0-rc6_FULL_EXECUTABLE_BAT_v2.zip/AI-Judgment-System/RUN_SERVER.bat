@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ==========================================
echo         AI Judgment System Server
echo ==========================================
echo.

if not exist "backend\app\main.py" (
    echo [ERROR] backend\app\main.py not found.
    echo Put this BAT file in the AI-Judgment-System root folder.
    echo.
    pause
    exit /b 1
)

cd /d "%~dp0backend"

rem --------------------------------------------------
rem 1) Reuse existing virtual environment if possible
rem --------------------------------------------------
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" -c "import sys" >nul 2>nul
    if not errorlevel 1 (
        goto :venv_ready
    )

    echo [INFO] Existing .venv is invalid. Recreating it...
    rmdir /s /q ".venv"
)

rem --------------------------------------------------
rem 2) Find any usable Python runtime
rem    Do NOT force Python 3.12.
rem --------------------------------------------------
set "PY_CMD="

where py >nul 2>nul
if not errorlevel 1 (
    py -3 -c "import sys" >nul 2>nul
    if not errorlevel 1 (
        set "PY_CMD=py -3"
        goto :python_found
    )

    py -c "import sys" >nul 2>nul
    if not errorlevel 1 (
        set "PY_CMD=py"
        goto :python_found
    )
)

where python >nul 2>nul
if not errorlevel 1 (
    python -c "import sys" >nul 2>nul
    if not errorlevel 1 (
        set "PY_CMD=python"
        goto :python_found
    )
)

where python3 >nul 2>nul
if not errorlevel 1 (
    python3 -c "import sys" >nul 2>nul
    if not errorlevel 1 (
        set "PY_CMD=python3"
        goto :python_found
    )
)

echo [ERROR] No usable Python runtime was found.
echo.
echo Install Python 3.x first, then run this file again.
echo During installation, enable "Add python.exe to PATH".
echo.
echo If the Python Launcher is installed, you can check detected versions with:
echo     py --list
echo.
pause
exit /b 1

:python_found
echo [SETUP] Creating Python virtual environment...
%PY_CMD% -m venv .venv

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] Failed to create .venv.
    echo.
    echo Detected Python command:
    echo     %PY_CMD%
    echo.
    pause
    exit /b 1
)

:venv_ready
rem --------------------------------------------------
rem 3) Install dependencies only when needed
rem --------------------------------------------------
".venv\Scripts\python.exe" -c "import uvicorn, fastapi, sqlalchemy, pydantic" >nul 2>nul
if errorlevel 1 (
    echo [SETUP] Installing project dependencies...
    ".venv\Scripts\python.exe" -m pip install --upgrade pip
    if errorlevel 1 goto :install_error

    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 goto :install_error
)

rem --------------------------------------------------
rem 4) Start server only
rem --------------------------------------------------
echo.
echo Server : http://127.0.0.1:8000
echo Docs   : http://127.0.0.1:8000/docs
echo Stop   : Ctrl+C
echo ------------------------------------------
echo.

".venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000

echo.
echo Server stopped.
pause
exit /b 0

:install_error
echo.
echo [ERROR] Failed to install dependencies.
echo Check your internet connection and backend\requirements.txt.
echo.
pause
exit /b 1
