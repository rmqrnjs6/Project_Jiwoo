# AI Judgment System

AI Judgment System(지우)의 **전체 실행용 레포지토리**입니다.

Backend, Frontend, 테스트, 실행 스크립트와 Docker 설정을 한 번에 사용할 수 있도록 구성했습니다.

현재 버전: **1.0.0-rc6**

---

## 1. 프로젝트 주제

여러 주장과 근거를 정리하고, 현재 확인 가능한 자료를 기준으로 판단 결과와 변화 과정을 관리하는 시스템입니다.

```text
Case 생성
→ Evidence 확인
→ 신뢰도 / 출처 평가
→ Judgment 생성
→ 새로운 근거 발생 시 재판단
→ History / Timeline 기록
```

---

## 2. 주요 기능

- Case 생성 및 조회
- Evidence 후보 탐색 및 선택
- Evidence 신뢰도 평가
- 출처 확인
- `SUPPORTED / CONTRADICTED / UNCERTAIN / INSUFFICIENT_EVIDENCE` 판단
- 새로운 Evidence에 따른 재판단
- `JUDGMENT_REVISED / JUDGMENT_REAFFIRMED` 구분
- History / Timeline
- Decision Snapshot
- Permission / Action 분리
- Cost Guard
- 결과 공유

---

## 3. 개발 환경

| 항목 | 버전 |
|---|---:|
| Python | **3.12** |
| FastAPI | **0.116.1** |
| Uvicorn | **0.35.0** |
| SQLAlchemy | **2.0.43** |
| Pydantic | **2.11.7** |
| psycopg | **3.2.9** |
| HTTPX | **0.28.1** |
| OpenAI Python SDK | **3.6.0** |
| Pytest | **8.4.1** |
| PostgreSQL | **17-alpine** |
| Frontend | **HTML / CSS / Vanilla JavaScript** |

---

## 4. 소스 구조

```text
AI-Judgment-System/
├─ README.md
├─ VERSION.txt
├─ Dockerfile
├─ compose.yaml
├─ .dockerignore
├─ .gitignore
├─ .env.example
├─ START_DOCKER.bat
├─ STOP_DOCKER.bat
│
├─ backend/
│  ├─ app/
│  ├─ tests/
│  ├─ scripts/
│  └─ requirements.txt
│
└─ frontend/
   ├─ index.html
   ├─ app.js
   └─ styles.css
```

### Backend

- `backend/app/main.py` : FastAPI 애플리케이션 및 API
- `backend/app/models.py` : 데이터 모델
- `backend/app/schemas.py` : 요청/응답 스키마
- `backend/app/evidence_discovery.py` : Evidence 후보 탐색
- `backend/app/reliability_engine.py` : 신뢰도 평가
- `backend/app/source_verification.py` : 출처 확인
- `backend/app/judgment_engine.py` : AI Judgment
- `backend/app/timeline.py` : Timeline 생성
- `backend/app/action_engine.py` : Permission / Action 처리
- `backend/app/release.py` : Release Lock
- `backend/app/response_composer.py` : 응답 구성
- `backend/app/support_engine.py` : 보조 처리
- `backend/app/database.py` : Database 연결

### Frontend

- `frontend/index.html` : 화면 구조
- `frontend/app.js` : API 호출과 화면 동작
- `frontend/styles.css` : UI 스타일

---

## 5. Docker 실행

먼저 `.env.example`을 복사해서 `.env`를 만듭니다.

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

OpenAI API를 사용할 경우 `.env`에 키를 입력합니다.

```text
OPENAI_API_KEY=본인_API_KEY
```

실행:

```powershell
docker compose up -d --build
```

또는 Windows에서 `START_DOCKER.bat`을 실행할 수 있습니다.

접속:

```text
http://localhost:8000
```

API 문서:

```text
http://localhost:8000/docs
```

종료:

```powershell
docker compose down
```

또는 `STOP_DOCKER.bat`을 실행합니다.

---

## 6. 테스트

Backend 폴더에서:

```powershell
python -m pytest -q
```

RC6 작성 테스트 기준으로 **77개 테스트가 통과한 이력**이 있습니다.

이 Lite 레포지토리는 기능별 분류본을 원래 실행 구조로 조립한 형태이며, 생성 후 동일 테스트를 다시 실행해 확인합니다.
