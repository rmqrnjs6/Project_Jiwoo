# 파일 용도: DB 연결과 세션 관리
import os
from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import DeclarativeBase, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./ai_judgment.db")

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args, future=True)

if DATABASE_URL.startswith("sqlite"):
    @event.listens_for(engine, "connect")
    def _enable_sqlite_foreign_keys(dbapi_connection, connection_record):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


# 기능: ORM 기본 클래스
class Base(DeclarativeBase):
    pass


# 기능: DB 세션 제공
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# 기능: DB 연결 확인
def check_database_ready() -> tuple[bool, str | None]:
    """Lightweight DB readiness check used by deployment probes."""
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        return True, None
    except Exception:
        return False, "DATABASE_UNAVAILABLE"


# 기능: DB 종류 반환
def database_backend_name() -> str:
    if DATABASE_URL.startswith("sqlite"):
        return "sqlite"
    if DATABASE_URL.startswith("postgresql"):
        return "postgresql"
    return "other"
